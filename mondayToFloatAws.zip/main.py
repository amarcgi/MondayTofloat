from com.icrossing.floatdotcom.FloatDotComDetails import FloatDotCom
from com.icrossing.mondaydotcom.MondayDotComDetails import MondayDotcom
import lambda_main
if __name__ == '__main__':
    lambda_main.startMondayToFLoat('', '');
    #mondayDotcom=MondayDotcom()
    #mondayDotcom.fetchMondayDotComDetsils()
    #mondayDotcom.deletProjectsFromFloat()
    #mondayDotcom.createProjecFloatDotcom()







