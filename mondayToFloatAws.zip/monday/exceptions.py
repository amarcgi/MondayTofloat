class MondayError(RuntimeError):
    pass
