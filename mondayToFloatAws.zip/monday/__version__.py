__version__ = '1.2.0'
__author__ = 'Christina D\'Astolfo'
__email__ = 'christina@prodperfect.com'
